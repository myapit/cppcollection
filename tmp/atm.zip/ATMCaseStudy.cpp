// ATMCaseStudy.cpp
// Driver program for the ATM case study.
#include "ATM.h" // ATM class definition

// main function creates and runs the ATM
int main()
{
	ATM atm; // create an ATM object
	atm.run(); // tell the ATM to start
} // end main
