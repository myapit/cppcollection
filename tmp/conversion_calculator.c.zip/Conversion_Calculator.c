#include<stdio.h>
#include<stdlib.h>
                                                     //Function prototype
/*--------Temperature conversion--------*/
int CelciustoFahrenheit(float *,float *);
int CelciustoKelvin(float *, float *);
int CelciustoRankine(float *, float *); 

int FahrenheittoCelcius(float *, float *);
int FahrenheittoKelvin(float *, float *);
int FahrenheittoRankine(float *, float *);

int KelvintoCelcius(float *, float *);
int KelvintoFahrenheit(float *, float *);
int KelvintoRankine(float *, float *); 

int RankinetoCelcius(float *, float *); 
int RankinetoFahrenheit(float *, float *); 
int RankinetoKelvin(float *, float *);

/*-----------Weight conversion------------*/
int GrainToMilligram(float *, float *);
int MilligramToGrain(float *, float *);

int OunceToGram(float *, float *);
int GramToOunce(float *, float *);

int PoundToKilogram(float *, float *);
int KilogramToPound(float *, float *);

int StoneToKilogram(float *, float *);
int KilogramToStone(float *, float *);

int GramToKilogram(float *, float *);
int KilogramToGram(float *, float *);

int HundredWeightToKilogram_Us(float *, float *);
int KilgramToHundredWeight_Us(float *, float *);

int HundredWeightToKilogram_Uk(float *, float *);
int KilgramToHundredWeight_Uk(float *, float *);

/*---------Length conversion------------------*/
int InchToCentimeter(float *, float *);
int CentimeterToInch(float *, float *);

int FeetToMeter(float *, float *);
int MeterToFeet(float *, float *);

int FeetToInch(float *, float *);
int InchToFeet(float *, float *);

int MileToKilometer(float *, float *);
int KilometerToMile(float *, float *);

int MileToNauticalmile(float *, float *);
int NauticalmileToMile(float *, float *);

int NauticalmileToKilometer(float *, float *);
int KilometerToNauticalmile(float *, float *);

/*---------------Currency conversion------------*/
int US_DollarToEuro(float *, float *);
int EuroToUS_Dollar(float *, float *);

int BRITISH_PoundToUS_Dollar(float *, float *);
int US_DollarToBRITISH_Pound(float *, float *);

int SWISS_FrancToUS_Dollar(float *, float *);
int US_DollarToSWISS_Franc(float *, float *);

int JAPANESE_YenToUS_Dollar(float *, float *);
int US_DollarToJAPANESE_Yen(float *, float *);

int SWISS_FrancToEuro(float *, float *);
int EuroToSWISS_Franc(float *, float *);

int SWISS_FrancToBRITISH_Pound(float *, float *);
int BRITISH_PoundToSWISS_Franc(float *, float *);

int BRITISH_PoundToEuro(float *, float *);
int EuroToBRITISH_Pound(float *, float *);

int JAPANESE_YenToEuro(float *, float *);
int EuroToJAPANESE_Yen(float *, float *);

int JAPANESE_YenToBRITISH_Pound(float *, float *);
int BRITISH_PoundToJAPANESE_Yen(float *, float *);

 
void Temperature_Conversion(void);
void Weight_Conversion(void);
void Length_Conversion(void);
void Currency_Conversion(void);
                                                   //Function definitoin

           //Temperature conversion
//Celcius 
int CelciustoFahrenheit(float *celcius, float *fahrenheit)
{
  *fahrenheit = (*celcius * 1.8) + 32;
  return(*fahrenheit); 
}  

int CelciustoKelvin(float *celcius, float *kelvin)
{
  *kelvin = *celcius + 273.15;
  return(*kelvin); 
}

int CelciustoRankine(float *celcius, float *rankine)
{
  *rankine = (*celcius + 273.15) * 1.8;
  return(*rankine);   
}
//Fahrenheit
int FahrenheittoCelcius(float *fahrenheit, float *celcius)
{
  *celcius = ((*fahrenheit - 32) * 5) / 9;
  return(*celcius); 
}

int FahrenheittoKelvin(float *fahrenheit, float *kelvin)
{
  *kelvin = ((*fahrenheit + 459.67) * 5) / 9;
  return(*kelvin); 
}

int FahrenheittoRankine(float *fahrenheit, float *rankine)
{
  *rankine = *fahrenheit + 459.67;
  return(*rankine); 
}
//Kelvin
int KelvintoCelcius(float *kelvin, float *celcius)
{
  *celcius = *kelvin - 273.15;
  return(*celcius);
}

int KelvintoFahrenheit(float *kelvin, float *fahrenheit)
{
  *fahrenheit = ((*kelvin * 1.8) - 459.67);
  return(*fahrenheit);
}

int KelvintoRankine(float *kelvin, float *rankine)
{
  *rankine = (*kelvin) * 1.8;
  return(*rankine);
}
//Rankine
int RankinetoCelcius(float *rankine, float *celcius)
{ 
  *celcius = ((*rankine - 491.67) * 5 ) / 9;
  return(*celcius);
}

int RankinetoFahrenheit(float *rankine, float *fahrenheit)
{
  *fahrenheit = *rankine - 459.67;
  return(*fahrenheit);
}

int RankinetoKelvin(float *rankine, float *kelvin)
{
  *kelvin = (*rankine * 5) / 9;
  return(*kelvin); 
}

           //Weight conversion
int GrainToMilligram(float *gr, float *mg)
{
  *mg = (*gr) * 64.7989;
  return(*mg); 
}

int MilligramToGrain(float *mg, float *gr)
{
  *gr = (*mg) * 0.01543;
  return(*gr);  
}

int OunceToGram(float *oz, float *gm)
{
  *gm = (*oz) * 28.3495;
  return(*gm); 
}
int GramToOunce(float *gm, float *oz)
{
  *oz = (*gm) * 0.0353;
  return(*oz);
}

int PoundToKilogram(float *lb, float *kg)
{
  *kg = (*lb) * 0.453592;
  return(*kg);
}
int KilogramToPound(float *kg, float *lb)
{
  *lb = (*kg) * 2.2046;
  return(*lb);
}

int StoneToKilogram(float *st, float *kg)
{
  *kg = (*st) * 6.35029;
  return(*kg);
}

int KilogramToStone(float *kg, float *st)
{
  *st = (*kg) * 0.1575;
  return(*st);
}

int GramToKilogram(float *gm, float *kg)
{
  *kg = (*gm) * 0.001;
  return(*kg);
}

int KilogramToGram(float *kg, float *gm)
{
  *gm = (*kg) * 1000;
  return(*gm);
}

int HundredWeightToKilogram_US(float *cwt, float *kg)
{
  *kg = (*cwt) * 45.35924;
  return(*kg);
}

int KilogramToHundredWeight_US(float *kg, float *cwt)
{
  *cwt = (*kg) * 0.02205;
  return(*cwt);
}

int HundredWeightToKilogram_UK(float *cwt, float *kg)
{
  *kg = (*cwt) * 50.80235;
  return(*kg);
}

int KilogramToHundredWeight_UK(float *kg, float *cwt)
{
  *cwt = (*kg) * 0.01968;
  return(*cwt);
}

           //Length conversion
int InchToCentimeter(float *inch, float *cm)
{
  *cm = (*inch) * 2.54;
  return(*cm);
}

int CentimeterToInch(float *cm, float *inch)
{
  *inch = (*cm) * 0.394;
  return(*inch);
}

int FeetToMeter(float *ft, float *m)
{
  *m = (*ft) * 0.3048;  
  return(*m);
}

int MeterToFeet(float *m, float *ft)
{
  *ft = (*m) * 3.281;
  return(*m);  
}

int FeetToInch(float *ft, float *inch)
{
  *inch = (*ft) * 12;
  return(*inch);
}

int InchToFeet(float *inch, float *ft)
{
  *ft = (*inch) * 0.0833;
  return(*ft);
}

int MileToKilometer(float *mile, float *km)
{
  *km = (*mile) * 1.609344;
  return(*km); 
}

int KilometerToMile(float *km, float *mile)
{
  *mile = (*km) * 0.6214;
  return(*mile);
}

int MileToNauticalmile(float *mile, float *nm)
{
  *nm = (*mile) * 0.868976;
  return(*nm);
}

int NauticalmileToMile(float *nm, float *mile)
{
  *mile = (*nm) * 1.1508;
  return(*mile);
}

int NauticalmileToKilometer(float *nm, float *km)
{
  *km = (*nm) * 1.852;
  return(*km);
}

int KilometerToNauticalmile(float *km, float *nm)
{
  *nm = (*km) * 0.5310;
  return(*nm); 
}

//Currency conversion
int US_DollarToEuro(float *ud, float *euro)
{
  *euro = (*ud) * 0.89;
  return(*euro);
}

int EuroToUS_Dollar(float *euro, float *ud)
{
  *ud = (*euro) * 1.1236;
  return(*ud);
}

int BRITISH_PoundToUS_Dollar(float *bp, float *ud)
{
  *ud = (*bp) * 1.52;
  return(*ud);
}
int US_DollarToBRITISH_Pound(float *ud, float *bp)
{
  *bp = (*ud) * 0.6579;
  return(*bp);
}

int SWISS_FrancToUS_Dollar(float *sf, float *ud)
{
  *ud = (*sf) * 1.03;
  return(*ud);
}
int US_DollarToSWISS_Franc(float *ud, float *sf)
{
  *sf = (*ud) * 0.9709;
  return(*ud);
}

int JAPANESE_YenToUS_Dollar(float *jy, float *ud)
{
  *ud = (*jy) * 0.0083;
  return(*ud);
}
int US_DollarToJAPANESE_Yen(float *ud, float *jy)
{
  *jy = (*ud) * 120.48;
  return(*jy);
}

int SWISS_FrancToEuro(float *sf, float *euro)
{
  *euro = (*sf) * 0.91;
  return(*euro);
}
int EuroToSWISS_Franc(float *euro, float *sf)
{
  *sf = (*euro) * 1.099;
  return(*sf);
}

int SWISS_FrancToBRITISH_Pound(float *sf, float *bp)
{
  *bp = (*sf) * 0.68;
  return(*bp);
}

int BRITISH_PoundToSWISS_Franc(float *bp, float *sf)
{
  *sf = (*bp) * 1.4706;
}

int BRITISH_PoundToEuro(float *bp, float *euro)
{
  *euro = (*bp) * 1.35;
  return(*euro);
}

int EuroToBRITISH_Pound(float *euro, float *bp)
{
  *bp = (*euro) * 0.7407;
  return(*bp);
}

int JAPANESE_YenToEuro(float *jy, float *euro)
{
  *euro = (*jy) * 0.0074;
  return(*euro);
}

int EuroToJAPANESE_Yen(float *euro, float *jy)
{
  *jy = (*euro) * 135.14;
  return(*jy);
}

int JAPANESE_YenToBRITISH_Pound(float *jy, float *bp)
{
  *bp = (*jy) * 0.0055;
  return(*bp);
}

int BRITISH_PoundToJAPANESE_Yen(float *bp, float *jy)
{
  *jy = (*bp) * 181.82;
  return(*jy);
}

           //Temperature conversion
void Temperature_Conversion(void)
{
  int choice;
  char ch;
  float fahrenheit, celcius, kelvin, rankine;
  do
  {
    system("clear");
    printf("\n\t\t * Temperature Converter *  \n");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\t\t| 0.|       Exit           |  ");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\t\t| 1.|Celcius to Fahrenheit |  ");
    printf("\n\t\t| 2.|Celcius to Kelvin     |  ");
    printf("\n\t\t| 3.|Celcius to Rankine    |  ");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\t\t| 4.|Fahrenheit to Celcius |  ");
    printf("\n\t\t| 5.|Fahrenheit to Kelvin  |  ");
    printf("\n\t\t| 6.|Fahrenheit to Rankine |  ");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\t\t| 7.|Kelvin to Celcius     |  ");
    printf("\n\t\t| 8.|Kelvin to Fahrenheit  |  ");
    printf("\n\t\t| 9.|Kelvin to Rankine     |  ");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\t\t|10.|Rankine to Celcius    |  ");
    printf("\n\t\t|11.|Rankine to Fahrenheit |  ");
    printf("\n\t\t|12.|Rankine to Kelvin     |  ");
    printf("\n\t\t+---+----------------------+  ");
    printf("\n\nEnter your choice: ");
    scanf("%d",&choice);

    switch(choice)
    {
	 case 0:
	   printf("\n\n\t\tExit from Temperature Converter...\n\n");
           return;
         break;

      //Celcius
      case 1:
         printf("\n\t......Celcius to Fahrenheit Converter......\n");
         printf("\n\tEnter the value of celcius: ");
         scanf("%f",&celcius);
         if (celcius < (-273.15)) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Celcius is -273.15...\n"); }
         else {
           CelciustoFahrenheit(&celcius, &fahrenheit);
           printf("\n\tTemperature in Fahrenheit : %f \n", fahrenheit); }
         break;

      case 2:
         printf("\n\t......Celcius to Kelvin Converter......\n");
         printf("\n\tEnter the value of Celcius: ");
         scanf("%f",&celcius);
         if(celcius < (-273.15)) {
           printf("\n\tThis conversion is not possible, because Absolute Tempareture in Celcius is -273.15...\n"); }
         else {
           CelciustoKelvin(&celcius, &kelvin);
           printf("\n\tTemperature in Kelvin : %f \n",kelvin); }
         break;

      case 3:
         printf("\n\t......Celcius to Rankine Converter......\n");
         printf("\n\tEnter the value of Celcius: ");
         scanf("%f",&celcius);
         if(celcius < (-273.15)) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Celcius is -273.15....\n"); }
         else {
           CelciustoRankine(&celcius, &rankine);
           printf("\n\tTemperature in Rankine : %f \n",rankine); }
         break;

      //Fahrenheit
      case 4:
         printf("\n\t......Fahrenheit to Celcius Converter......\n");
         printf("\n\tEnter the value of Fahrenheit: ");
         scanf("%f",&fahrenheit);
         if(fahrenheit < (-458)) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Fahrenheit is -459.67....\n"); }
         else {
           FahrenheittoCelcius(&fahrenheit, &celcius);
           printf("\n\tTemperature in Celcius : %f \n",celcius); }
         break;

      case 5:
         printf("\n\t......Fahrenheit to Kelvin Converter......\n");
         printf("\n\tEnter the value of Fahrenheit: ");
         scanf("%f",&fahrenheit);
         if(fahrenheit < (-458)) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Fahrenheit is -459.67....\n"); }
         else {
           FahrenheittoKelvin(&fahrenheit, &kelvin);
           printf("\n\tTemperature in Kelvin : %f \n",kelvin); }
         break;

      case 6:
         printf("\n\t......Fahrenheit to Rankine Converter......\n");      
         printf("\n\tEnter the value of Fahrenheit: ");
         scanf("%f",&fahrenheit);
         if(fahrenheit < (-458)) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Fahrenheit is -459.67....\n"); }
         else {
           FahrenheittoRankine(&fahrenheit, &rankine);
           printf("\n\tTemperature in Rankine : %f \n",rankine); }
         break;

     //Kelvin
      case 7:
         printf("\n\t......Kelvin to Celcius Converter......\n");
         printf("\n\tEnter the value of Kelvin: ");
         scanf("%f",&kelvin);
         if(kelvin < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Kelvin is zero....\n"); }
         else {
           KelvintoCelcius(&kelvin, &celcius);
           printf("\n\tTemperature in Celcius : %f \n",celcius); }
         break;
      
      case 8:
         printf("\n\t......Kelvin to Fahrenheit Converter......\n");
         printf("\n\tEnter the value of Kelvin: ");
         scanf("%f",&kelvin);
         if(kelvin < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Kelvin is zero....\n"); }
         else {
           KelvintoFahrenheit(&kelvin, &fahrenheit);
           printf("\n\tTemperature in Fahrenheit : %f \n",fahrenheit); }
         break;

      case 9:
         printf("\n\t......Kelvin to Rankine Converter......\n");
         printf("\n\tEnter the value of Kelvin: ");
         scanf("%f",&kelvin);
         if(kelvin < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Kelvin is zero....\n"); }
         else {
           KelvintoRankine(&kelvin, &rankine);
           printf("\n\tTemperature in Rankine : %f \n",rankine); }
         break;

      //Rankine
      case 10:
         printf("\n\t......Rankine to Celcius Converter......\n");
         printf("\n\tEnter the value of Rankine: ");
         scanf("%f",&rankine);
         if(rankine < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Rankine is zero....\n"); }
         else {
           RankinetoCelcius(&rankine, &celcius);
           printf("\n\tTemperature in Celcius : %f \n",celcius); }
         break;

      case 11:
         printf("\n\t......Rankine to Fahrenheit Converter......\n");
         printf("\n\tEnter the value of Rankine: ");
         scanf("%f",&rankine);
         if(rankine < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Rankine is zero...\n"); }
         else {
           RankinetoFahrenheit(&rankine, &fahrenheit);
           printf("\n\tTemperature in Fahrenheit : %f \n",fahrenheit); }
         break;

      case 12:
         printf("\n\tRankine to Kelvin Converter...\n");
         printf("\n\tEnter the value of Rankine: ");
         scanf("%f",&rankine);
         if(rankine < 0) {
           printf("\n\tThis conversion is not possible because Absolute Tempareture in Rankine is zero...\n"); }
         else {
           RankinetoKelvin(&rankine, &kelvin);
           printf("\n\tTemperature in Kelvin : %f \n",kelvin); }
         break;

      default: 
         printf("\n\t\tYou choose wrong option...\n\tPlease read the Menu carefully before enter your choice...\n");
         break;
    }
    getchar();			
    printf("\n\n\tDo you want to continue Temperature Converter???\n\tIf Yes,press 'y', else 'n'.\n");
   ch = getchar();		
  }while(ch!='n'); 

  return;
}

           //Weight conversion
void Weight_Conversion(void)
{
  int choice;
  float kg, oz, gm, lb, st, gr, mg, cwt;
  char ch;

  do
  {
    system("clear");
    printf("\n\t\t       - Weight Converter -        \n");
    printf("\n\t\t+---+-----------------------------+  ");
    printf("\n\t\t| 0.|      Exit                   |  ");
    printf("\n\t\t+---+-----------------------------+  ");
    printf("\n\t\t| 1.|Grain To Milligram           |  ");
    printf("\n\t\t| 2.|Milligram To Gram            |  ");
    printf("\n\t\t| 3.|Ounce To Gram                |  ");
    printf("\n\t\t| 4.|Gram To Ounce                |  ");
    printf("\n\t\t| 5.|Pound To Kilogram            |  ");
    printf("\n\t\t| 6.|Kilogram To Pound            |  ");
    printf("\n\t\t| 7.|Stone To Kilogram            |  ");
    printf("\n\t\t| 8.|Kilogram To Stone            |  ");
    printf("\n\t\t| 9.|Gram To Kilogram             |  ");
    printf("\n\t\t|10.|Kilogram To Gram             |  ");
    printf("\n\t\t|11.|HundredWeight To Kilogram(US)|  ");
    printf("\n\t\t|12.|Kilogram To HundredWeight(US)|  ");
    printf("\n\t\t|13.|HundredWeight To Kilogram(UK)|  ");
    printf("\n\t\t|14.|Kilogram To HundredWeight(UK)|  ");
    printf("\n\t\t+---+-----------------------------+  ");

    printf("\n\nEnter your choice: ");
    scanf("%d",&choice);
    
    switch(choice)
    {
      case 0:
        printf("\n\n\tExit from Weight Converter....\n\n");
        return;
        break;

      case 1:
        printf("\n\t......Grain To Milligram Converter......\n");
        printf("\n\tEnter the value Grain : ");
        scanf("%f",&gr);
        GrainToMilligram(&gr, &mg);
        printf("\n\tWeight in Milligram : %f \n", mg);
        break;

      case 2:
        printf("\n\t......Milligram To Grain Converter......\n");
        printf("\n\tEnter the value Milligram : ");
        scanf("%f",&mg);
        MilligramToGrain(&mg, &gr);
        printf("\n\tWeight in Grain : %f \n", gr);
        break;

      case 3:
        printf("\n\t......Ounce To Gram Converter......\n");
        printf("\n\tEnter the value Ounce : ");
        scanf("%f",&oz);
        OunceToGram(&oz, &gm);
        printf("\n\tWeight in Gram : %f \n", gm);
        break;

      case 4:
        printf("\n\t......Gram To Ounce Converter......\n");
        printf("\n\tEnter the value Gram : ");
        scanf("%f",&gm);
        GramToOunce(&gm, &oz);
        printf("\n\tWeight in Ounce : %f \n", oz);
        break;

      case 5:
        printf("\n\t......Pound To Kilogram Converter......\n");
        printf("\n\tEnter the value Pound : ");
        scanf("%f",&lb);
        PoundToKilogram(&lb, &kg);
        printf("\n\tWeight in Kilogram : %f \n", kg);
        break;

      case 6:
        printf("\n\t......Kilogram To Pound Converter......\n");
        printf("\n\tEnter the value Kilogram : ");
        scanf("%f",&kg);
        KilogramToPound(&kg, &lb);
        printf("\n\tWeight in Pound : %f \n", lb);
        break;

      case 7:
        printf("\n\t......Stone To Kilogram Converter......\n");
        printf("\n\tEnter the value Stone : ");
        scanf("%f",&st);
        StoneToKilogram(&st, &kg);
        printf("\n\tWeight in Kilogram : %f \n", kg);
        break;

      case 8:
        printf("\n\t......Kilogram To Stone Converter......\n");
        printf("\n\tEnter the value Kilogram : ");
        scanf("%f",&kg);
        KilogramToStone(&kg, &st);
        printf("\n\tWeight in Stone : %f \n", st);
        break;

      case 9:
        printf("\n\t......Gram To Kilogram Converter......\n");
        printf("\n\tEnter the value Gram : ");
        scanf("%f",&gm);
        GramToKilogram(&gm, &kg);
        printf("\n\tWeight in Kilogram : %f \n", kg);
        break;

      case 10:
        printf("\n\t......Kilogram To Gram Converter......\n");
        printf("\n\tEnter the value Kilogram : ");
        scanf("%f",&kg);
        KilogramToGram(&kg, &gm);
        printf("\n\tWeight in Gram : %f \n", gm);
        break;

      case 11:
        printf("\n\t......HundredWeight To Kilogram(US) Converter......\n");
        printf("\n\tEnter the value HundredWeight : ");
        scanf("%f",&cwt);
        HundredWeightToKilogram_US(&cwt, &kg);
        printf("\n\tWeight in Kilogram : %f \n", kg);
        break;

      case 12:
        printf("\n\t......Kilogramg To HundredWeight(US) Converter......\n");
        printf("\n\tEnter the value Kilogram : ");
        scanf("%f",&kg);
        KilogramToHundredWeight_US(&kg, &cwt);
        printf("\n\tWeight in HundredWeight : %f \n", cwt);
        break;

      case 13:
        printf("\n\t......HundredWeight To Kilogram(UK) Converter......\n");
        printf("\n\tEnter the value HundredWeight : ");
        scanf("%f",&cwt);
        HundredWeightToKilogram_UK(&cwt, &kg);
        printf("\n\tWeight in Kilogram : %f \n", kg);
        break;

      case 14:
        printf("\n\t......Kilogramg To HundredWeight(UK) Converter......\n");
        printf("\n\tEnter the value Kilogram : ");
        scanf("%f",&kg);
        KilogramToHundredWeight_UK(&kg, &cwt);
        printf("\n\tWeight in HundredWeight : %f \n", cwt);
        break;

      default:
        printf("\n\t\tYou choose wrong option......\n\tPlease read the Menu carefully before enter your choice...\n");
        break;
    }
    getchar();
    printf("\n\n\tDo you want to continue Weight Converter??\n\tIf Yes,press 'y', else 'n'.\n");
    ch = getchar();
  }while(ch != 'n');

  return;
} 

           //Length conversion
void Length_Conversion(void)
{
  int choice;
  float inch, cm, m, ft, mile, km, nm;
  char ch;

  do
  {
    system("clear");
    printf("\n\t\t     !! Length Converter !!     \n");
    printf("\n\t\t+---+-------------------------+  ");
    printf("\n\t\t| 0.|      Exit               |  ");
    printf("\n\t\t+---+-------------------------+  ");
    printf("\n\t\t| 1.|Inch To Centimeter       |  ");
    printf("\n\t\t| 2.|Centimeter To Inch       |  ");
    printf("\n\t\t| 3.|Feet To Meter            |  ");
    printf("\n\t\t| 4.|Meter To Feet            |  ");
    printf("\n\t\t| 5.|Feet To Inch             |  ");
    printf("\n\t\t| 6.|Inch To Feet             |  ");
    printf("\n\t\t| 7.|Mile To Kilometer        |  ");
    printf("\n\t\t| 8.|Kilometer To Mile        |  ");
    printf("\n\t\t| 9.|Mile To Nauticalmile     |  ");
    printf("\n\t\t|10.|Nauticalmile To Mile     |  ");
    printf("\n\t\t|11.|Nauticalmile To Kilometer|  ");
    printf("\n\t\t|12.|Kilometer To Nauticalmile|  ");
    printf("\n\t\t+---+-------------------------+  ");

    printf("\n\n\tEnter your choice: ");
    scanf("%d",&choice);
   
    switch(choice)
    {
      case 0:
	printf("\n\n\tExit from Length Converter....\n\n");
        return;
        break;

      case 1:
        printf("\n\t......Inch To Centimeter Converter......\n");
        printf("\n\tEnter the value Inch : ");
        scanf("%f",&inch);
        InchToCentimeter(&inch, &cm);
        printf("\n\tLength in Centimeter : %f \n", cm);        
        break;

      case 2:
        printf("\n\t......Centimeter To Inch Converter......\n");
        printf("\n\tEnter the value Centimeter : ");
        scanf("%f",&cm);
        CentimeterToInch(&cm, &inch);
        printf("\n\tLength in Inch : %f \n", inch);
        break;

      case 3:
        printf("\n\t......Feet To Meter Converter......\n");
        printf("\n\tEnter the value Feet : ");
        scanf("%f",&ft);
        FeetToMeter(&ft, &m);
        printf("\n\tLength in Meter : %f \n", m);
        break;

      case 4:
        printf("\n\t......Meter To Feet Converter......\n");
        printf("\n\tEnter the value Meter : ");
        scanf("%f",&m);
        MeterToFeet(&m, &ft);
        printf("\n\tLength in Feet : %f \n", ft);
        break;

      case 5:
        printf("\n\t......Feet To Inch Converter......\n");
        printf("\n\tEnter the value Feet : ");
        scanf("%f",&ft);
        FeetToInch(&ft, &inch);
        printf("\n\tLength in Inch : %f \n", inch);
        break;

      case 6:
        printf("\n\t......Inch To Feet Converter......\n");
        printf("\n\tEnter the value Inch : ");
        scanf("%f",&inch); 
        InchToFeet(&inch, &ft);
        printf("\n\tLength in Feet : %f \n", ft);
        break;

      case 7:
        printf("\n\t......Mile To Kilometer Converter......\n");
        printf("\n\tEnter the value Mile : ");
        scanf("%f",&mile);
        MileToKilometer(&mile, &km);
        printf("\n\tLength in Kilometer : %f \n", km);
        break;

      case 8:
        printf("\n\t......Kilometer To Mile Converter......\n");
        printf("\n\tEnter the value Kilometer : ");
        scanf("%f",&km);
        KilometerToMile(&km, &mile);
        printf("\n\tLength in Mile : %f \n", mile);
        break;

      case 9:
        printf("\n\t......Mile To Nauticalmile Converter......\n");
        printf("\n\tEnter the value mile : ");
        scanf("%f",&mile);
        MileToNauticalmile(&mile, &nm);
        printf("\n\tLength in Nauticalmile : %f \n", nm);
        break;

      case 10:
        printf("\n\t......Nauticalmile To Mile Converter......\n");
        printf("\n\tEnter the value Nauticalmile : ");
        scanf("%f",&nm); 
        NauticalmileToMile(&nm, &mile);
        printf("\n\tLength in Mile : %f \n", mile);
        break;

      case 11:
        printf("\n\t......Nauticalmile To Kilometer Converter......\n");
        printf("\n\tEnter the value Nauticalmile : ");
        scanf("%f",&nm);
        NauticalmileToKilometer(&nm, &km);
        printf("\n\tLength in Kilometer : %f \n", km);
        break;

      case 12:
        printf("\n\t......Kilometer To Nauticalmile Converter......\n");
        printf("\n\tEnter the value kilometer : ");
        scanf("%f",&km);
        KilometerToNauticalmile(&km, &nm);
        printf("\n\tLength in Nauticalmile : %f \n", nm);
        break;

      default:
        printf("\n\t\tYou choose wrong option...\n\t\tPlease read the Menu carefully before enter your choice...\n");
        break;    
    }
    getchar();
    printf("\n\n\t\tDo you want to continue Length Converter??\n\t\tIf Yes,press 'y', else 'n'.\n");
    ch = getchar();
  }while(ch != 'n');

  return;
}
//currency converter
void Currency_Conversion(void)
{
  int choice;
  char ch;
  float ud, euro, bp, sf, jy;
  do
  {
    system("clear");
    printf("\n\t\t      + Currency Converter +      \n");
    printf("\n\t\t+---+-----------------------------+  ");
    printf("\n\t\t| 0.|       Exit                  |  ");
    printf("\n\t\t+---+-----------------------------+  ");
    printf("\n\t\t| 1.|US_Dollar To Euro            |  ");
    printf("\n\t\t| 2.|Euro To US_Dollar            |  ");
    printf("\n\t\t| 3.|BRITISH_Pound To US_Dollar   |  ");
    printf("\n\t\t| 4.|US_Dollar To BRITISH_Pound   |  ");
    printf("\n\t\t| 5.|SWISS_Franc To US_Dollar     |  ");
    printf("\n\t\t| 6.|US_Dollar To SWISS_Franc     |  ");
    printf("\n\t\t| 7.|JAPANESE_Yen To US_Dollar    |  ");
    printf("\n\t\t| 8.|US_Dollar To JAPANESE_Yen    |  ");
    printf("\n\t\t| 9.|SWISS_Franc To Euro          |  ");
    printf("\n\t\t|10.|Euro To SWISS_Franc          |  ");
    printf("\n\t\t|11.|SWISS_Franc To BRITISH_Pound |  ");
    printf("\n\t\t|12.|BRITISH_Pound To SWISS_Franc |  ");
    printf("\n\t\t|13.|BRITISH_Pound To Euro        |  ");
    printf("\n\t\t|14.|Euro To BRITISH_Pound        |  ");
    printf("\n\t\t|15.|JAPANESE_Yen To Euro         |  ");
    printf("\n\t\t|16.|Euro To JAPANESE_Yen         |  ");
    printf("\n\t\t|17.|JAPANESE_Yen To BRITISH_Pound|  ");
    printf("\n\t\t|18.|BRITISH_Pound To JAPANESE_Yen|  ");
    printf("\n\t\t+---+-----------------------------+  ");

    printf("\n\n\tEnter your choice: ");
    scanf("%d",&choice);

    switch(choice)
    {
      case 0:
	printf("\n\n\tExit from Currency Converter....\n\n");
        return;
        break;

      case 1:
        printf("\n\t......US_Dollar To Euro Converter......\n");
        printf("\n\tEnter the value US_Dollar : ");
        scanf("%f",&ud);
        US_DollarToEuro(&ud, &euro); 
        printf("\n\tWeight in Euro : %f \n", euro);
        break;

      case 2:
        printf("\n\t......Euro To US_Dollar Converter......\n");
        printf("\n\tEnter the value Euro : ");
        scanf("%f",&euro); 
        EuroToUS_Dollar(&euro, &ud);
        printf("\n\tWeight in US_Dollar : %f \n", ud);
        break;

      case 3:
        printf("\n\t......BRITISH_Pound To US_Dollar Converter......\n");
        printf("\n\tEnter the value BRITISH_Pound : ");
        scanf("%f",&bp);
        BRITISH_PoundToUS_Dollar(&bp, &ud);
        printf("\n\tWeight in US_Dollar : %f \n", ud);
        break;

      case 4:
        printf("\n\t......US_Dollar To BRITISH_Pound Converter......\n");
        printf("\n\tEnter the value US_Dollar : ");
        scanf("%f",&ud);
        US_DollarToBRITISH_Pound(&ud, &bp); 
        printf("\n\tWeight in BRITISH_Pound : %f \n", bp);
        break;

      case 5:
        printf("\n\t......SWISS_Franc To US_Dollar Converter......\n");
        printf("\n\tEnter the value SWISS_Franc : ");
        scanf("%f",&sf); 
        SWISS_FrancToUS_Dollar(&sf, &ud);
        printf("\n\tWeight in US_Dollar : %f \n", ud);
        break;

      case 6:
        printf("\n\t......US_Dollar To SWISS_Franc Converter......\n");
        printf("\n\tEnter the value US_Dollar : ");
        scanf("%f",&ud); 
        US_DollarToSWISS_Franc(&ud, &sf);
        printf("\n\tWeight in SWISS_Franc : %f \n", sf);
        break;

      case 7:
        printf("\n\t......JAPANESE_Yen To US_Dollar Converter......\n");
        printf("\n\tEnter the value JAPANESE_Yen : ");
        scanf("%f",&jy); 
        JAPANESE_YenToUS_Dollar(&jy, &ud);
        printf("\n\tWeight in US_Dollar : %f \n", ud);
        break;

      case 8:
        printf("\n\t......US_Dollar To JAPANESE_Yen Converter......\n");
        printf("\n\tEnter the value US_Dollar : ");
        scanf("%f",&ud); 
        US_DollarToJAPANESE_Yen(&ud, &jy);
        printf("\n\tWeight in JAPANESE_Yen : %f \n", jy);
        break;

      case 9:
        printf("\n\t......SWISS_Franc To Euro Converter......\n");
        printf("\n\tEnter the value SWISS_Franc : ");
        scanf("%f",&sf); 
        SWISS_FrancToEuro(&sf, &euro);
        printf("\n\tWeight in Euro : %f \n", euro);
        break;

      case 10:
        printf("\n\t......Euro To SWISS_Franc Converter......\n");
        printf("\n\tEnter the value Euro : ");
        scanf("%f",&euro); 
        EuroToSWISS_Franc(&euro, &sf);
        printf("\n\tWeight in SWISS_Franc : %f \n", sf);
        break;

      case 11:
        printf("\n\t......SWISS_Franc To BRITISH_Pound Converter......\n");
        printf("\n\tEnter the value SWISS_Franc : ");
        scanf("%f",&sf); 
        SWISS_FrancToBRITISH_Pound(&sf, &bp);
        printf("\n\tWeight in BRITISH_Pound : %f \n", bp);
        break;

      case 12:
        printf("\n\t......BRITISH_Pound To SWISS_Franc Converter......\n");
        printf("\n\tEnter the BRITISH_Pound : ");
        scanf("%f",&bp); 
        BRITISH_PoundToSWISS_Franc(&bp, &sf);
        printf("\n\tWeight in SWISS_Franc : %f \n", sf);
        break;

      case 13:
        printf("\n\t......BRITISH_Pound To Euro Converter......\n");
        printf("\n\tEnter the value BRITISH_Pound : ");
        scanf("%f",&bp); 
        BRITISH_PoundToEuro(&bp, &euro);
        printf("\n\tWeight in Euro : %f \n", euro);
        break;

      case 14:
        printf("\n\t......Euro To BRITISH_Pound Converter......\n");
        printf("\n\tEnter the value Euro : ");
        scanf("%f",&euro); 
        EuroToBRITISH_Pound(&euro, &bp);
        printf("\n\tWeight in BRITISH_Pound : %f \n", bp);
        break;

      case 15:
        printf("\n\t......JAPANESE_Yen To Euro Converter......\n");
        printf("\n\tEnter the value JAPANESE_Yen : ");
        scanf("%f",&jy);
        JAPANESE_YenToEuro(&jy, &euro); 
        printf("\n\tWeight in Euro : %f \n", euro);
        break;

      case 16:
        printf("\n\t......Euro To JAPANESE_Yen......\n");
        printf("\n\tEnter the value Euro : ");
        scanf("%f",&euro); 
        EuroToJAPANESE_Yen(&euro, &jy);
        printf("\n\tWeight in JAPANESE_Yen : %f \n", jy);
        break;

      case 17:
        printf("\n\t......JAPANESE_Yen To BRITISH_Pound Converter......\n");
        printf("\n\tEnter the value JAPANESE_Yen : ");
        scanf("%f",&jy); 
        JAPANESE_YenToBRITISH_Pound(&jy, &bp);
        printf("\n\tWeight in BRITISH_Pound : %f \n", bp);
        break;

      case 18:
        printf("\n\t......BRITISH_Pound To JAPANESE_Yen Converter......\n");
        printf("\n\tEnter the value BRITISH_Pound : ");
        scanf("%f",&bp); 
        BRITISH_PoundToJAPANESE_Yen(&bp, &jy);
        printf("\n\tWeight in JAPANESE_Yen : %f \n", jy);
        break;

      default:
        printf("\n\t\tYou choose wrong option...\n\n\t\tPlease read the Menu carefully before enter your choice...\n"); 
        break;
    }
   getchar();
   printf("\n\n\tDo you want to continue Currency Converter??\n\tIf Yes,press 'y', else 'n'.\n");
    ch = getchar();
  }while(ch != 'n');

  return;
}
                                                                                //Main 
int main(void)
{
  int choice;
  char ch;

  do
  {
    system("clear");
    printf("\n\n\t\t\tWelcome to CONVERTER CALCULATOR...\n\n\n\n\n\n");
    printf("\n\t\t        :: M E N U ::   ");
    printf("\n\t\t+---+-----------------------+  ");
    printf("\n\t\t| 0.|      Exit             |  ");
    printf("\n\t\t+---+-----------------------+  ");
    printf("\n\t\t| 1.|Temperature Converter  |  ");
    printf("\n\t\t| 2.|Weight Converter       |  ");
    printf("\n\t\t| 3.|Length Converter       |  ");
    printf("\n\t\t| 4.|Currency Converter     |  ");
    printf("\n\t\t+---+-----------------------+  ");

    printf("\n\n\tEnter your choice: ");
    scanf("%d",&choice);
    
    switch(choice)
    {
      case 0:
        printf("\n\n\t\tYou choose Exit from CONVERTER CALCULATOR...\n\n");
        break;

      case 1:
        Temperature_Conversion();
        break;

      case 2:
        Weight_Conversion();
        break;
     
     case 3:
        Length_Conversion();
        break;

     case 4:
        Currency_Conversion();
        break;

      default:
        printf("\n\t\tSorry!!\n\n\t\tPlease read the Menu carefully before enter choice...\n");
        break;
    }
    getchar();
    printf("\n\n\n\n\n\n\n\t\tDo you want to continue CONVERTER CALCULATOR??\n\t\tIf Yes,press 'y', else 'n'.\n");
    ch = getchar();
  }while(ch != 'n');
   
  system ("clear");
  printf("\n\n\n\n\n\t\tGood Bye...\n\n\n\t\tThanks for using it...\n\n\n\n\n\n\n\n");
  return(1);
}

