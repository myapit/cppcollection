Created By: JM Rosendal
Email: agent.suwastica@gmail.com

Details
1. POS System of Burger stores
2. No database.
3. With inventory
4. with senior discount(12%)
5. With waste inventory
6. with return & exchange inventory
7. Press Alt+Enter to view full screen
8. For Visual C++ 6.0 Console Application
9. Inventory password: lowest
10. Cashier: user: jm, password: jm
11. Press 'S' for down arrow and 'W' for up arrow
12. Press Enter to select and Backspace to back.
13. See help for more details.
