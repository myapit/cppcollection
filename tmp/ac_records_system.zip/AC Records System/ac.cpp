	#include <iostream>
	#include <conio.h>
	#include <fstream>
	#include <iomanip>
    #include <stdlib.h>
	using namespace std; void abc(); void xyz(); //declaration..
	 
	//character strings. if you want to add some numbers that related to your Ages, Mobile. use DOUBLE.
    char myName[50]; char AC;  const int XampaChar = 50 ;char myLocation[XampaChar];
    double AC_QUEST_NW; 
	
    //main window 
	main() {  int acselect; system("color AC");system("title AC RECORDING SYSTEM [C++]");do{cout << "\n\n\n\a\t\t\t [MAIN MENU]\n";
              cout << "\a\a\n 1 = ADD RECORDS "; cout << " 2 = VIEW RECORDS "; cout << " 3 = QUIT SYSTEM = ";
           	  cin >> acselect;
           	  
	      if (acselect == 1)
	         abc();
             else if (acselect == 2)
	              xyz();
             else
                  cout<<"SYNTAX ERROR"; } while (acselect!= 3 );}
	
    // input records 
	void abc() {  system("color CA"); cout << "\n\nWHAT IS YOUR NAME ? "; cin.ignore();
	              cin.getline(myName,50); 

       ofstream outfile; outfile.open("ACRecords.txt",ios::app); //write records	 
	   outfile << myName;
	   outfile << setprecision(12)<< AC;
	   outfile.close(); system("color 1B");system("cls"); cout << "\a\aPRESS ANY KEY TO CONTINUE! " ;
	   getch();}
	
    //output records 
	void xyz(){ system("color B1"); system("cls"); cout << "\n\nTYPE THE RECORDED NAME = "; cin >> AC_QUEST_NW; 
       ifstream infile; infile.open("ACRecords.txt"); //read records
	   while(!infile.eof() && infile != '\0'){
	      infile.getline(myName,50);
	      infile >> AC; infile.ignore();
	      infile.getline(myLocation,50); infile.ignore();
	  
	      if(AC == AC_QUEST_NW){
	         cout << "DISPLAY NAME: "; cout << myName;
             cout << setprecision(12) << AC;
             break;}}
	         if(infile.eof() && AC != AC_QUEST_NW)  { cout << "\nRECORDS IS EMPTY! \n\n";  }  infile.close();
                     cout << "\n\nPRESS ANY KEY TO CONTINUE!\n\n"; system("color 3A");  getch();}

